#pragma once

#ifndef _BITFONT_H_
#define _BITFONT_H_

GLvoid glPrint(const char*fmt,...);

#endif