#include "WeaponClass.h"


ippWeaponClass::ippWeaponClass ( void )
{
}


ippWeaponClass::~ippWeaponClass ( void )
{
}

void ippWeaponClass::FireWeapon ( Vec3D position, Vec3D direction )
{
}

void ippWeaponClass::FireMissile ( Vec3D position, Vec3D direction, Vec3D* tPosition )
{
}