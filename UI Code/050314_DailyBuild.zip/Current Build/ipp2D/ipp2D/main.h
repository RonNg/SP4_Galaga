

void KeyboardDown(unsigned char key, int x, int y);
void KeyboardUp(unsigned char key, int x, int y);

	/*
	Never gonna give you up
	Never gonna let you down
	Never gonna run around and desert you
	Never gonna make you cry
	Never gonna say good bye
	Never gonna tell a lie and hurt you
	*/