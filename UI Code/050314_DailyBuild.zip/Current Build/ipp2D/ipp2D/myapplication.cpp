#include "myapplication.h"
#include <mmsystem.h>
#include "Camera\Camera.h"

#include "Managers\ObjectManager.h"
#include "Managers\GameManager.h"
#include "Managers\CollisionManager.h"

#include "Systems\EnemySpawner.h"
#include "SaveGame\SaveManager.h"
#include "Entities\Asteroids\AsteroidManager.h"
#include "Entities\PowerUps\PowerUpManager.h"

#include "Entities\Ship\Ship.h"


myApplication * myApplication::s_pInstance = NULL;

// you can use constructor to initialise variables
myApplication::myApplication()
	:theCamera(NULL)
{
	BuildFont();
	startgame = false;
	JoyKeyPress = false;
}

myApplication::~myApplication()
{
	if ( theCamera != NULL )
	{
	
		delete theCamera;
	}
	KillFont();
	enableShoot = true;
}

myApplication* myApplication::getInstance()
{
	if(s_pInstance == NULL)
	{
		s_pInstance = new myApplication();
	}
	return s_pInstance;
}

void myApplication::changeSize(int w, int h) {

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h == 0)
		h = 1;

	float ratio = (float) (1.0f* w / h);

	// Reset the coordinate system before modifying
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, w, h);

	// Set the correct perspective.
	gluPerspective(45,ratio,1,1000);
	glMatrixMode(GL_MODELVIEW);
}

void myApplication::inputKey(int key, int x, int y) {

	//switch (key) {
	//	case GLUT_KEY_LEFT : 
	//		moveMeSideway(true, 1.0f);break;
	//	case GLUT_KEY_RIGHT : 
	//		moveMeSideway(false, 1.0f);break;
	//	case GLUT_KEY_UP : 
	//		moveMeForward(true, 1.0f);break;
	//	case GLUT_KEY_DOWN : 
	//		moveMeForward(false, 1.0f);break;
	//}
}

void myApplication::KeyboardDown(unsigned char key, int x, int y){

	myKeys[key]= true;
}

void myApplication::KeyboardUp(unsigned char key, int x, int y){

	myKeys[key]= false;
}

void myApplication::MouseMove (int x, int y) {
	mouseInfo.lastX = x - Global::HEIGHT_RESOLUTION/2;
	mouseInfo.lastY = Global::WIDTH_RESOLUTION/2 - y;
	
	////Checking mouse boundary. 
	//// 800 is the window width. 
	//// You may need to change this to suit your program.
	//if (mouseInfo.lastX > 800-20 || mouseInfo.lastX < 20)
	//{
	//	mouseInfo.lastX = (800 >> 1);
	//	glutWarpPointer(mouseInfo.lastX, mouseInfo.lastY);
	//}
	//// 600 is the window height. 
	//// You may need to change this to suit your program.
	//if (mouseInfo.lastY > 600-20 || mouseInfo.lastY < 20)
	//{
	//	mouseInfo.lastY = (600 >> 1);
	//	glutWarpPointer(mouseInfo.lastX, mouseInfo.lastY);
	//}
}

void myApplication::MouseClick(int button, int state, int x, int y) 
{
	
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{	
		mouseInfo.mLButtonDown = true;	
	}
	else
	{
		mouseInfo.mLButtonDown = false;
	}
}


//-------------------------------------------------------------------------
// Calculates the frames per second
//-------------------------------------------------------------------------
void myApplication::calculateFPS()
{
	//  Increase frame count
	frameCount++;

	//  Get the number of milliseconds since glutInit called
	//  (or first call to glutGet(GLUT ELAPSED TIME)).
	currentTime = glutGet(GLUT_ELAPSED_TIME);

	//  Calculate time passed
	int timeInterval = currentTime - previousTime;

	if(timeInterval > 1000)
	{
		//  calculate the number of frames per second
		fps = frameCount / (timeInterval / 1000.0f);

		//  Set time
		previousTime = currentTime;

		//  Reset frame count
		frameCount = 0;
	}
	/*
	We're no strangers to love 
	You know the rules and so do I 
	A full commitment's what I'm thinking of 
	You wouldn't get this from any other guy 
	I just wanna tell you how I'm feeling 
	Gotta make you understand 

	Never gonna give you up, 
	Never gonna let you down 
	Never gonna run around and desert you 
	Never gonna make you cry, 
	Never gonna say goodbye 
	Never gonna tell a lie and hurt you 

	We've known each other for so long 
	Your heart's been aching but you're too shy to say it 
	Inside we both know what's been going on 
	We know the game and we're gonna play it 
	And if you ask me how I'm feeling 
	Don't tell me you're too blind to see
	
	Never gonna give you up, 
	Never gonna let you down 
	Never gonna run around and desert you 
	Never gonna make you cry, 
	Never gonna say goodbye 
	Never gonna tell a lie and hurt you 

	(Ooh give you up) 
	(Ooh give you up) 
	(Ooh) never gonna give, never gonna give 
	(give you up) 
	(Ooh) never gonna give, never gonna give 
	(give you up) 

	We've known each other for so long 
	Your heart's been aching but you're too shy to say it 
	Inside we both know what's been going on 
	We know the game and we're gonna play it
	And if you ask me how I'm feeling 
	Don't tell me you're too blind to see

	Never gonna give you up, 
	Never gonna let you down 
	Never gonna run around and desert you 
	Never gonna make you cry, 
	Never gonna say goodbye 
	Never gonna tell a lie and hurt you 
	*/
}

//-------------------------------------------------------------------------
//  Draw FPS
//-------------------------------------------------------------------------
void myApplication::drawFPS()
{
	glPushMatrix();
		//  Load the identity matrix so that FPS string being drawn
		//  won't get animates
		glLoadIdentity ();
		glPushAttrib(GL_DEPTH_TEST);
		glDisable(GL_DEPTH_TEST);

			//  Print the FPS to the window
			if (fps > 28.30f)
				glColor3f( 0.0f, 1.0f, 1.0f);
			else if (fps > 28.0f)
				glColor3f( 0.0f, 1.0f, 0.0f);
			else 
				glColor3f( 1.0f, 0.0f, 0.0f);
			printw ( 25.0, 25.0, 0, "FPS: %4.2f", fps );

		glPopAttrib();
		glMatrixMode(GL_PROJECTION);
	glPopMatrix();
}

//-------------------------------------------------------------------------
//  Draws a string at the specified coordinates.
//-------------------------------------------------------------------------
void myApplication::printw (float x, float y, float z, char* format, ...)
{
	va_list args;	//  Variable argument list
	int len;		//	String length
	int i;			//  Iterator
	char * text;	//	Text

	//  Initialize a variable argument list
	va_start(args, format);

	//  Return the number of characters in the string referenced the list of arguments.
	//  _vscprintf doesn't count terminating '\0' (that's why +1)
	len = _vscprintf(format, args) + 1; 

	//  Allocate memory for a string of the specified size
	text = (char *)malloc(len * sizeof(char));

	//  Write formatted output using a pointer to the list of arguments
	vsprintf_s(text, len, format, args);

	//  End using variable argument list 
	va_end(args);

	//  Specify the raster position for pixel operations.
	glRasterPos3f (x, y, z);


	//  Draw the characters one by one
	for (i = 0; text[i] != '\0'; i++)
		glutBitmapCharacter(font_style, text[i]);

	//  Free the allocated memory for the string
	free(text);
}

void myApplication::rungame()
{
	if(startgame)
	{
		ippObjectManager::GetInstance()->Render();
		ippGameManager::GetInstance()->Render();
	}
}

void myApplication::Joystick(unsigned int buttonMask, int x, int y, int z)
{
	// left = -x
	// right = x
	// up = -y
	// down = y
	// right trigger = -z
	// left trigger = z
	// A = 1, B=2 , x=4, y =8 , left bumper = 16, right bumber = 32, back = 64, start = 128, left analouge = 256, right analough = 516

	switch (buttonMask){
	case 1:
		JoystickA = true;
		break;
	case 128:
		click = true;
		break;
	case 64:
		back = true;
		break;
	}

	if (x < -400)
	{
		JoystickLeft = true;
	}
	else 
			JoystickLeft = false;


	if (x > 400)
	{
		JoystickRight = true;
	}
	else
		JoystickRight = false;


	if(z < -800)
	{
		if (JoyKeyPress == false)
		{
			JoyKeyPress = true;
			JoystickRightTrigger = true;

		}
	}
	else if(z > 400)
	{
		JoystickLeftTrigger = true;
	}
	else
	{
		JoyKeyPress = false;
	}

	if (y < -400)
	{
		JoystickUp = true;
	}

	else if (y > 400)
	{
		JoystickDown = true;
	}
}

void myApplication::DrawBar(const int PowerUpTime, const int MaxPowerUpTime)
{
	glBegin(GL_QUADS);
		glTexCoord2f(0,0); glVertex2f(600,500);
		glTexCoord2f(1,0); glVertex2f(600,500 + HeightOfBar);
		glTexCoord2f(1,1); glVertex2f(600+((float)PowerUpTime/MaxPowerUpTime)*WidthOfBar,500 + HeightOfBar);
		glTexCoord2f(0,1); glVertex2f(600+((float)PowerUpTime/MaxPowerUpTime)*WidthOfBar,500);	
	glEnd();
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glBegin(GL_QUADS);
		glTexCoord2f(0,0); glVertex2f(600,500);
		glTexCoord2f(1,0); glVertex2f(600,500 + HeightOfBar);
		glTexCoord2f(1,1); glVertex2f(600+WidthOfBar,500 + HeightOfBar);
		glTexCoord2f(0,1); glVertex2f(600+WidthOfBar,500);	
	glEnd();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

bool myApplication::Init(void)
{
	playonce =true;
	theSoundEngine = createIrrKlangDevice();
	if(!theSoundEngine)
		return false;
	theGameUI = new GameUI();
	HeightOfBar = 30;
	WidthOfBar = 150;
	// Set camera position
	theCamera = new ippCamera( ippCamera::LAND_CAM );
	theCamera->SetPosition( 0.0, 2.0, -5.0 );
	theCamera->SetDirection( 0.0, 0.0, 1.0 );

	glEnable(GL_TEXTURE_2D);			// Enable Texture Mapping
	glDisable(GL_TEXTURE_2D);

	//  The number of frames
	frameCount = 0;
	//  Number of frames per second
	fps = 0;

	currentTime = 0, previousTime = 0;

	font_style = GLUT_BITMAP_HELVETICA_18;
	
	// realtime loop control
	Global::curFrameTime=timeGetTime();
	Global::prevFrameTime = Global::curFrameTime;

	frequency = 35.0f;

	for(int i=0; i<255; i++)
	{
		myKeys[i] = false;
	}
	mouseInfo.mLButtonDown = false;

	theGameUI->AddMenu("Splash","Images/SplashScreen.tga");

	theGameUI->AddMenu("Main Menu","Images/Background.tga");

	theGameUI->AddButton("Start",400,300);
	theGameUI->AddButton("Shop",400, 350);
	theGameUI->AddButton("Quit", 400, 400);

	theGameUI->AddMenu("Game Start","Images/GameScreen.tga");

	// Insert Game Screen here

	theGameUI->AddMenu("Shop","Images/ShopScreen.tga");
	theGameUI->AddButton("ShipSpeed",400,50);
	theGameUI->AddButton("ShipEvasion",400,100);
	theGameUI->AddButton("BulletSpeed",400,150);
	theGameUI->AddButton("BulletLevel",400,200);
	theGameUI->AddButton("MissileSpeed",400,250);
	theGameUI->AddButton("MissileTurnSpeed",400,300);
	theGameUI->AddButton("DroneFireRate",400,350);
	theGameUI->AddButton("Back",400,400);
	

	theGameUI->Move("Splash");

	/*
	===========================================
	Any user created initialization codes 
	should be placed here onwards.
	===========================================
	*/
	
	/*
	===========================================
	Init the save file
	===========================================
	*/

	if ( ! ( ippSaveManager::GetInstance()->Init( "GameUpgrades.txt" ) ) )
	{
		// Adding all the catagories
		ippSaveManager::GetInstance ()->AddCategory ( "BULLETSPEED" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "1", "BULLETSPEED" );

		ippSaveManager::GetInstance ()->AddCategory ( "BULLETLEVEL" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "2", "BULLETLEVEL" );

		ippSaveManager::GetInstance ()->AddCategory ( "MISSILESPEED" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "1", "MISSILESPEED" );

		ippSaveManager::GetInstance ()->AddCategory ( "MISSILETURNSPEED" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "5", "MISSILETURNSPEED" );

		ippSaveManager::GetInstance ()->AddCategory ( "SHIPSPEED" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "1", "SHIPSPEED" );

		ippSaveManager::GetInstance ()->AddCategory ( "SHIPEVASION" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "1", "SHIPEVASION" );

		ippSaveManager::GetInstance ()->AddCategory ( "DRONERATE" );
		ippSaveManager::GetInstance ()->AddInformationInto ( "1", "DRONERATE" );
	}
//////////////////////////////////////////////////////////////////////////////

	// Starting lua
	lua_State *L = lua_open();

	// Load the libs
	luaL_openlibs(L);
	// Loading the lua file
	if(luaL_loadfile(L, "config.lua") || lua_pcall(L, 0, 0, 0))
	{
		printf("Error: &s", lua_tostring(L, -1));
	}
	
	lua_getglobal(L, "SHIPSIZEX");
	float SHIPSIZEX = (float)lua_tonumber(L, -1);

	lua_getglobal(L, "SHIPSIZEY");
	float SHIPSIZEY = (float)lua_tonumber(L, -1);
	

	// Getting the levels from the save file
	int shipSpeed = ippSaveManager::GetInstance ()->GetInt ( "SHIPSPEED" );
	int shipEvasion = ippSaveManager::GetInstance ()->GetInt ( "SHIPEVASION " );

	playerShip = new ippShip (Global::WIDTH_RESOLUTION/2, Global::HEIGHT_RESOLUTION - 25, 0.0f, SHIPSIZEX, SHIPSIZEY );
	playerShip->Init( shipSpeed, shipEvasion );

	//asteroidManager = new ippAsteroidManager ();
	//asteroidManager->Init ();

	//powerupManager = new ippPowerUpManager ();
	//powerupManager->Init ();

	ippGameManager::GetInstance()->Init();

	lua_close(L);
	return true;
}
void myApplication::IO_Handler()
{
	// Joystick Left
	if(JoystickLeft == true)
	{
		playerShip->Movement(ippShip::LEFT);
	}
	// Joystick Right
	if(JoystickRight == true)
	{
		playerShip->Movement(ippShip::RIGHT);
	}
	// Joystick Up	
	if(	JoystickUp == true)
	{
		theGameUI->Update(true);
		JoystickUp = false;
	}
	// Joystick Down
	else if ( JoystickDown == true)
	{
		theGameUI->Update(false);
		JoystickDown = false;
	}
	//Right Trigger
	if(	JoystickRightTrigger == true)
	{
		if ( enableShoot == true )
		{
			playerShip->FireBullet();
			enableShoot = false;
			JoystickRightTrigger = false;
		}
	}
	// Button A
	if( JoystickA == true)
	{
		command = theGameUI->Identity();
		JoystickA = false;
	}
	//Back button
	if(back == true)
	{
		cout<<theGameUI->PreviousPage<<endl;
		theGameUI->Move("Back")	;
		back = false;
	}
}
void myApplication::Update(void) 
{
	
	IO_Handler();

	if (theGameUI->page() == "Splash")
	{

		if (playonce == true)
		{
			Sound_BGM = theSoundEngine->play2D("Sounds/Theme_Song.mp3",false);
			playonce = false;
		}
		if(click == true)
		{
			theGameUI->Move("Main Menu");	
			theSoundEngine->stopAllSounds();
			click = false;
		}
	}
	else if (theGameUI->page() == "Main Menu")
	{
		if (command == "Start" )
		{
			theGameUI->Move("Game Start");
			Sound_ThemeSong = theSoundEngine->play2D("Sounds/Level_Start.mp3",false);
			startgame = true;

		}
		else if  (command == "Shop")
		{
			// Getting the levels from the save file
			shipSpeed = ippSaveManager::GetInstance ()->GetInt ( "SHIPSPEED" );
			cout << shipSpeed << endl;
			shipEvasion = ippSaveManager::GetInstance ()->GetInt ( "SHIPEVASION " );

			bulletSpeed = ippSaveManager::GetInstance ()->GetInt ( "BULLETSPEED" );
			bulletLevel = ippSaveManager::GetInstance ()->GetInt ( "BULLETLEVEL" );

			missileSpeed = ippSaveManager::GetInstance ()->GetInt ( "MISSILESPEED" );
			missileTurnSpeed = ippSaveManager::GetInstance ()->GetInt ( "MISSILETURNSPEED" );

			droneFireRate = ippSaveManager::GetInstance ()->GetInt ( "DRONERATE" );

			theGameUI->Move("Shop");
		}
		else if  (command == "Quit")
		{
			glutLeaveMainLoop();
		}

		command = 0;
	}

	else if (theGameUI->page() == "Shop");
	{
		if ( command == "ShipSpeed" )
		{
			cout << shipSpeed << endl;
			if ( shipSpeed < 5 )
			{
				shipSpeed += 1;
			}
			else
			{
				// Error msg
			}
		}

		else if ( command == "ShipEvasion" )
		{
			if ( shipEvasion < 5 )
			{
				shipEvasion += 1;
			}
			else
			{
				// Error msg
			}
		}

		else if ( command == "BulletSpeed" )
		{
			if ( bulletSpeed < 5 )
			{
				bulletSpeed += 1;
			}
			else
			{
				// Error msg
			}
		}

		else if ( command == "BulletLevel" )
		{
			if ( bulletLevel < 5 )
			{
				bulletLevel += 1;
			}
			else
			{
				// Error msg
			}
		}

		else if ( command == "MissileSpeed" )
		{
			if ( missileSpeed < 5 )
			{
				missileSpeed += 1;
			}
			else
			{
				// Error msg
			}
		}

		else if ( command == "MissileTurnSpeed" )
		{
			if ( missileTurnSpeed < 5 )
			{
				missileTurnSpeed += 1;
			}
			else
			{
				// Error msg
			}
		}

		else if ( command == "DroneFireRate" )
		{
			if ( droneFireRate > 5 )
			{
				droneFireRate += 1;
			}
			else
			{
				// Error msg
			}
		
		}
		else if(command == "Back")
		{
			theGameUI->Move("Main Menu");
		}
		command = 0;

	if( myKeys[27] == true )
		glutLeaveMainLoop();
	
	if ( GetAsyncKeyState(VK_LEFT) )
	{
		playerShip->Movement(ippShip::LEFT);
	}
	
	if ( GetAsyncKeyState(VK_RIGHT) )
	{
		playerShip->Movement(ippShip::RIGHT);
	} 

	if ( GetAsyncKeyState ( VK_SPACE ) )
	{
		if ( enableShoot == true )
		{
			playerShip->FireBullet();
			enableShoot = false;
		}
	}
	else
	{
		enableShoot = true;
	}

	if ( GetAsyncKeyState ( VK_RETURN ) )
	{
		if ( ippObjectManager::GetInstance ()->GetRandomObjByTag ( "Enemy" ) != NULL )
		{
			playerShip->FireMissile ( ippObjectManager::GetInstance ()->GetRandomObjByTag ( "Enemy" ) );
		}
	}
	else
		{
			enableShoot = true;
		}
	//asteroidManager->Update ();
	//powerupManager->Update ();
	}
}
void myApplication::Render(void)
{
	// Clear the buffer
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();
	theCamera->Update();

	ippGameManager::GetInstance()->Update();
	ippCollisionManager::GetInstance()->Update();
	if ((timeGetTime()- Global::prevFrameTime)>1000/frequency)
	{
		// Calculate the framerate
		calculateFPS();
		Global::prevFrameTime = Global::curFrameTime;
		Global::curFrameTime = timeGetTime();
		
	
		Global::timedelta = 1000 / this->fps / (Global::curFrameTime - Global::prevFrameTime);

		//Temporary fix. 
		//Make the game wait 5 seconds before starting as the starting fps affects movement
		if ( fps < 5 )
			Global::timedelta = 1;

		Global::prevFrameTime = Global::curFrameTime;
		Update();
	}
	// Enable 2D text display and HUD

	theCamera->SetHUD( true );
	
	
	
		if(startgame)
			rungame();
		if(theGameUI->page() == "Splash" )
		{
			static float colortemp = 1.0f;							// temp for color changing
			glColor3f(colortemp,colortemp,colortemp);
			glRasterPos2f(225,525);
			glPrint("[PRESS START TO CONTINUE]");
			colortemp-=0.03f;
			if(colortemp <=0.0f)
				colortemp = 1.0f;
			glColor3f(1,1,1);
		}

		if(theGameUI->page() == "Game Start")
		{
		static float postemp	= 1.0f;
		static float colortemp	= 1.0f;	// temp for color changing
		static float accel		= 5.0f;

			glColor3f(1,1,1);
			glRasterPos2f(postemp,325);
			glPrint("WAVE");
			postemp += accel;

			glRasterPos2f(555,050);
			glPrint("HIGHSCORE:");	
			glRasterPos2f(555,150);
			glPrint("LIVES:");

			DrawBar(0,10);

		}

	drawFPS();
	theCamera->SetHUD( false );	

	// Flush off any entity which is not drawn yet, so that we maintain the frame rate.
	glFlush();
	// swapping the buffers causes the rendering above to be shown
	glutSwapBuffers();

}
void myApplication::TestRender ()
{
	Vec3D dimensions(200.0f, 592.0f, 0);
		
	glEnable(GL_BLEND);
	glBlendFunc (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	
	
	glPushMatrix();
		glTranslatef(596, 4, 0);
		glColor4f( 0.0f, 1.0f, 0.0f, 1.0f );
		glBegin(GL_QUADS);
			glTexCoord2f( 0, 1 ); glVertex2f( 0, 0);
			glTexCoord2f( 0, 0 ); glVertex2f( 0, dimensions.y);
			glTexCoord2f( 1, 0 ); glVertex2f( dimensions.x, dimensions.y );
			glTexCoord2f( 1, 1 ); glVertex2f( dimensions.x, 0);
		glEnd();
	glPopMatrix();

	glDisable(GL_BLEND);
	glDisable(GL_TEXTURE_2D);

}