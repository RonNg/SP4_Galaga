#pragma once
#include "Managers\CollisionManager.h"
namespace Global
{
	extern float prevFrameTime; // time of previous frame
	extern float curFrameTime; // time of current frame
	extern float timedelta;

	extern int HEIGHT_RESOLUTION;
	extern int WIDTH_RESOLUTION;
};

/*
	We've known each other for so long
	You know the rules, and so do I
	A full commitment's what I'm thinking of
	You wouldn't get this from any other guy
	I just wanna tell you how I'm feeling
	Gotta make you understand
*/