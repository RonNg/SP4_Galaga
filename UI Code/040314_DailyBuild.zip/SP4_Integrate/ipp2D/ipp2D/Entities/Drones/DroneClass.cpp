#include "DroneClass.h"


ippDroneClass::ippDroneClass(void)
{
}


ippDroneClass::~ippDroneClass(void)
{
	delete position;
}

void ippDroneClass::Init ( void )
{

}